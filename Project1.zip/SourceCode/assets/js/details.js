function send(){
    var firstname = document.getElementById('ftname');
    var lastname = document.getElementById('ltname');
    var email = document.getElementById('txtemail');
    var phonenum = document.getElementById('txtphonenum');
    var errorFirstname = document.getElementById('fname');
    var errorLastname = document.getElementById('lname');
    var errorEmail = document.getElementById('email');
    var errorPhonenum = document.getElementById('phonenum');
    if (firstname.value == '')
    { 
        errorFirstname.style.display = 'block';
        firstname.focus();
        return;
    }
    else{
        errorFirstname.style.display = 'none';
    }

    if(lastname.value == ''){
        errorLastname.style.display = 'block';
        lastname.focus();
        return;
    }
    else {
        errorLastname.style.display = 'none';
    }

    if(email.value == ''){
        errorEmail.style.display = 'block';
        email.focus();
        return;
    }
    else {
        errorEmail.style.display = 'none';
    }

    if(phonenum.value == ''){
        errorPhonenum.style.display = 'block';
        phonenum.focus();
        return;
    }
    else {
        errorPhonenum.style.display = 'none';
        document.write("<div style=' width: 100%; height: 100vh; display: flex; flex-direction: column; justify-content: center; align-items: center; '><div><img style='width: 100px; height: 100px; margin-bottom: 70px;' src='assets/img/thumbnail/successfully.png' alt='success'></div><div style='font-size: 32px;'> Sent to seller!</div></div>");
        setTimeout(function(){
                window.location.href = "Home.html";
            },3000);
    }
}