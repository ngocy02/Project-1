function signIn(){
    var first = document.getElementById("fn");
    var last = document.getElementById("ln");
    var acpt =/^[0-9A-Za-z]+(@)[0-9a-zA-Z.]+$/;
    var email = document.getElementById("eml");
    var password = document.getElementById("pw");
    var errorfname = document.getElementById("errorfn");
    var errorlname = document.getElementById("errorln");
    var errorRequired = document.getElementById("errorRequired");
    var errorInvalid = document.getElementById("errorInvalid");
    var errorPassword = document.getElementById("errorPassword");
    var errorPasswordlength = document.getElementById("errorPasslength");
    if(first.value == ""){
        errorfname.style.display = 'block';
        first.focus();
        return;
    }
    else{
        errorfname.style.display = 'none';
    }

    if(last.value == ""){
        errorlname.style.display = 'block';
        last.focus();
        return;
    }
    else{
        errorlname.style.display = 'none';
    }

    if(email.value == ""){
        errorRequired.style.display = 'block';
        email.focus();
        return;
    }
    else{
        errorRequired.style.display = 'none';
    }
    
    if(!acpt.test(email.value)){
        errorInvalid.style.display = 'block';
        email.focus();
        return;
    }
    else{
        errorInvalid.style.display = 'none';
    }


    if(password.value == ""){
        errorPassword.style.display = 'block';
        password.focus();
        return;
    }
    else{
        errorPassword.style.display = 'none';
    }

    if (eval(password.value.length) <=6){
        errorPasswordlength.style.display = 'block';
        password.focus();
        return;
    }
    else{
        errorPasswordlength.style.display = 'none';
        document.write("<div style=' width: 100%; height: 60vh; display: flex; flex-direction: column; justify-content: center; align-items: center; '><div><img style='width: 100%; height: 150px; margin-bottom: 70px;' src='assets/img/thumbnail/logoFont.jpg' alt='success'></div><div style='font-size: 25px; text-transform: capitalize;'>Hello! "+ first.value + " " + last.value +"</div></div>");
        setTimeout(function(){
                window.location.href = "Home.html";
            },3000);
    }
}