//check support for geolocation in the browser
if (navigator.geolocation) {
    //locateposition and invoke function
    navigator.geolocation.getCurrentPosition(displayPosition, errorFunction);
} 
else {
    alert("Geolocation is not enabled in your browser");
}
// success function
function displayPosition(position){
    var my_lat = position.coords.latitude;
    var my_lng = position.coords.longitude;
    // var div_info = document.getElementById("user_location");
    // div_info.innerHTML = "<h1>Latitude is: " + my_lat + "and longitude is " + my_lng + "</h1>";

    // load gg maps
    var latlng = new google.maps.LatLng(my_lat, my_lng);
    var myOptions = {
        zoom: 14,//the initial resolution is set at which map is displayed
        center: latlng,//centers the map
        mapTypeId: google.maps.MapTypeId.ROADMAP //sets the map type
    };

    //Creates the map object
    var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
    
    // Display icon on the located position
    var marker = new google.maps.Marker({
        position: latlng,
        map: map,
        title: "User location"
    });
}

//Error callback function
function errorFunction(pos){
    alert("Error!");
}