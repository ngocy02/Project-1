function query1(id)
{
    var mycar = document.getElementById(id);
    if (mycar.style.display == 'none')
        mycar.style.display = 'block';
    else
        mycar.style.display = 'none';
}
function query2(id)
{
    var dropping = document.getElementById(id);
    if (dropping.style.display == 'none')
        dropping.style.display = 'block';
    else
        dropping.style.display = 'none';
}
function query3(id)
{
var contactUs = document.getElementById(id);
if (contactUs.style.display == 'none')
    contactUs.style.display = 'block';
else
    contactUs.style.display = 'none';
}
function next(){
    var re = /^[^OQIa-z]{17}$/;
    var vin = document.getElementById('txtVin');
    var error = document.getElementById('vin-error');
    if (vin.value == "" || (!re.test(vin.value))){
        error.style.display = "block";
    }
    else{
        error.style.display = "none";
    document.write("<div style=' width: 100%; height: 35vh; display: flex; flex-direction: column; justify-content: center; align-items: center; '><div><img style='width: 60px; height: 60px; margin-bottom: 10px;' src='assets/img/thumbnail/false.jpg' alt='false'></div><div style='font-size: 18px; text-align: center;'>VIN is missing or invalid <br><font color='red'> VIN number " + vin.value + " could not be successfully looked up.</font></div></div>");
    setTimeout(function(){
        window.location.href = "Sell.html";
    }, 3000)
    }
}
// var vin = document.getElementById("txtVin").value;
// function next(){
// }
