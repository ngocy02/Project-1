function query1(id) {
    var query1 = document.getElementById(id);
    if (query1.style.display == 'none')
        query1.style.display = 'block';
    else
        query1.style.display = 'none';
}
function query2(id) {
    var query2 = document.getElementById(id);
    if (query2.style.display == 'none')
        query2.style.display = 'block';
    else
        query2.style.display = 'none';
}
function query3(id) {
    var query3 = document.getElementById(id);
    if (query3.style.display == 'none')
        query3.style.display = 'block';
    else
        query3.style.display = 'none';
}
function query4(id) {
    var query4 = document.getElementById(id);
    if (query4.style.display == 'none')
        query4.style.display = 'block';
    else
        query4.style.display = 'none';
}
function query5(id) {
    var query5 = document.getElementById(id);
    if (query5.style.display == 'none')
        query5.style.display = 'block';
    else
        query5.style.display = 'none';
}
function query6(id) {
    var query6 = document.getElementById(id);
    if (query6.style.display == 'none')
        query6.style.display = 'block';
    else
        query6.style.display = 'none';
}
function query7(id) {
    var query7 = document.getElementById(id);
    if (query7.style.display == 'none')
        query7.style.display = 'block';
    else
        query7.style.display = 'none';
}