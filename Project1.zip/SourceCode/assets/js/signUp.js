function signUp(){
    var fname = document.getElementById("fname");
    var lname = document.getElementById("lname");
    var re =/^[0-9A-Za-z]+(@)[0-9a-zA-Z.]+$/;
    var email = document.getElementById("email");
    var phonenum = document.getElementById("phone");
    var password = document.getElementById("pass");
    var agree = document.getElementById("ckagree");
    var errorFirstName = document.getElementById("firstName");
    var errorLastName = document.getElementById("lastName");
    var errorEmailRequired = document.getElementById("emailRequired");
    var errorEmailInvalid = document.getElementById("emailInvalid");
    var errorPhone = document.getElementById("phonerequired");
    var errorPhonenumber = document.getElementById("phonenumber");
    var errorPassword = document.getElementById("password");
    var errorPasswordlength = document.getElementById("passwordlength");
    var errorAccept = document.getElementById("accept");
    if(fname.value == ""){
        errorFirstName.style.display = 'block';
        fname.focus();
        return;
    }
    else{
        errorFirstName.style.display = 'none';
    }

    if(lname.value == ""){
        errorLastName.style.display = 'block';
        lname.focus();
        return;
    }
    else{
        errorLastName.style.display = 'none';
    }

    if(email.value == ""){
        errorEmailRequired.style.display = 'block';
        email.focus();
        return;
    }
    else{
        errorEmailRequired.style.display = 'none';
    }
    
    if(!re.test(email.value)){
        errorEmailInvalid.style.display = 'block';
        email.focus();
        return;
    }
    else{
        errorEmailInvalid.style.display = 'none';
    }

    if(phonenum.value == ""){
        errorPhone.style.display = 'block';
        phonenum.focus();
        return;
    }
    else{
        errorPhone.style.display = 'none';
    }

    if(isNaN(phonenum.value)){
        errorPhonenumber.style.display = 'block';
        phonenum.focus();
        return;
    }
    else{
        errorPhonenumber.style.display = 'none';
    }

    if(password.value == ""){
        errorPassword.style.display = 'block';
        password.focus();
        return;
    }
    else{
        errorPassword.style.display = 'none';
    }

    if (eval(password.value.length) <=6){
        errorPasswordlength.style.display = 'block';
        password.focus();
        return;
    }
    else{
        errorPasswordlength.style.display = 'none';
    }
    if(!(agree.checked)){
        errorAccept.style.display = 'block';
        return;
    }
    else{
        errorAccept.style.display = 'none';
        // displayed when successful sign up
        document.write("<div style=' width: 100%; height: 100vh; display: flex; flex-direction: column; justify-content: center; align-items: center; '><div><img style='width: 100px; height: 100px; margin-bottom: 70px;' src='assets/img/thumbnail/successfully.png' alt='success'></div><div style='font-size: 32px;'>Congratulations, your account has been successfully created.</div></div>");
        setTimeout(function(){
                window.location.href = "Home.html";
            },3000);
    }
}